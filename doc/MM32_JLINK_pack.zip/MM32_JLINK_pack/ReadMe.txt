two ways to install the J-Link Pack:
1. Unzip the zip file, Copy
Unzip the zip file, Copy below folder Files and to the JLink install folder, replace JLinkDevices.xml files;
JLink must to be 6.10 or over 6.10 version
for example: Jlink is installed to:
C:\Program Files (x86)\SEGGER\JLink


\Devices\MindMotion\***.***  (Series Files must to be copied with Administrator)
\JLinkDevices.xml (Covered Current Files)

2. use install file, auto search Segger files folder, then install files
