
JLink pack release notes
--------------------------------------------------------------------------------
version 0.98  2022.04.18
1. Delete MM32F3277 series with specificated Device list;
--------------------------------------------------------------------------------
version 0.97  2022.02.09
1.  Add suppport MM32F0040, MM32F0020, MM32L0130 and MM32F5270 series with specificated Device list;
--------------------------------------------------------------------------------
version 0.96  2021.10.14
1.  Add suppport MM32F0140 series with specificated Device list;
2.  add install exe file
--------------------------------------------------------------------------------
version 0.91  2021.07.28
1. Add support MM32SPIN26 series with specificated Device list;
--------------------------------------------------------------------------------
version 0.90  2021.06.10
1. Add support MM32F027x series with specificated Device list;
2. Add support MM32SPIN028x series with specificated Device list;
3. change FLM files
--------------------------------------------------------------------------------
version 0.80  2021.04.10
1.  Add suppport Legacy series with specificated Device list to cover the Jlink Dll part numbers;
--------------------------------------------------------------------------------
version 0.70  2020.12.10
1.  Add suppport MM32F327x series with specificated Device list;
2.  Change MindMotion MM32F0010xx series to specificated Device list;
3.  Change MindMotion MM32F013x series to specificated Device list;
4.  Change MindMotion MM32F003xx series to specificated Device list;
5.  Move MindMotion MM32F032xx series;
6.  Change MindMotion MM32L36xx series to specificated Device list;
7.  change MindMotion MM32L37xx series to specificated Device list;
8.  Change MindMotion MM32L05xx series to specificated Device list;
9.  change MindMotion MM32L07xx series to specificated Device list;
10. Move MindMotion MM32L06xx series;
11. Change MindMotion MM32SPIN05xx series to specificated Device list;
12. Move MindMotion MM32SPIN06xx series;
13. Change MindMotion MM32SPIN25xx series to specificated Device list;
14. change MindMotion MM32SPIN27xx series to specificated Device list;
15. change MM32W0xx and MM32W3xx series to specificated Device list;

version 0.6   2020.11.06

1.  update MindMotion MM32F0010 FLM file to Fix MM32F0010 program function
2.  change FLM files to use Erase to move RDP mode;
3.  add MM32W0xx and MM32W3xx series

version 0.5   2020.08.19

1.  add MindMotion MM32F0010 series device
2.  add MindMotion MM32F0130 series device